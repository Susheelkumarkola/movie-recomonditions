# movie_recommender_system
git lfs install
git clone <repository-url>
brew install git-lfs
git lfs pull
pip install streamlit
pip install pickle 
pip install requests 